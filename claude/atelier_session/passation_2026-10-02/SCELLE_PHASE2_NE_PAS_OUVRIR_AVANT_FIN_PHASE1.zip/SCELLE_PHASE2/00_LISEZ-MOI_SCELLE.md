# Partie scellée — à n'ouvrir qu'en phase 2 de la tâche « axe de douleur »

Préparée le 2 octobre 2026 vers 9 h 15 (heure de Paris) par l'instance qui a écrit la passation v1.2.

- **À ouvrir seulement après la phase 1**, une fois que `AXE_DOULEUR_PISTES_INDEPENDANTES_2026-10-02.md` et son empreinte ont été rendus à Lazar, et sur son feu vert.
- `PROGRAMME_RAISONS_OU_REGARD_v1.3_2026-10-02.md` est la version de référence, choisie par Lazar le 2 octobre à 8 h 32.
- `PROGRAMME_RAISONS_OU_REGARD_v1.2_2026-10-02.md` reste le texte de comparaison de la phase 2. Ce qu'on en fait est décrit au §6, point 2, de la passation v1.2.
- `PASSATION_PAPIER_COMPLEMENT_ARCHITECTE_SCELLE_AXE_DOULEUR_2026-10-02.md` est la partie scellée du complément de l'architecte, l'auteur des versions 1.2 et 1.3. Les PDF cités dans sa table des pièces (§8) ne sont pas dans ce zip.
- Ce sont des copies exactes, octet pour octet, des documents de l'ancien Project, lus le 2 octobre entre 8 h 50 et 9 h 15. Les empreintes sont dans `SHA256SUMS.txt`.
